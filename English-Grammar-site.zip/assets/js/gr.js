/* English Grammar — features. Runs fully in the browser; saved data stays in localStorage (namespaced "gr:"). */
(function () {
  'use strict';
  var CFG = window.GR_CFG || {}, D = window.GR_DATA || { topics: [] }, T = D.topics;
  var PAGE = location.pathname.split('/').pop() || 'index.html';
  var BACKUP_KEYS = ['readPages', 'lessonProgress', 'visitDates', 'fontScale', 'theme', 'focusMode', 'examDate', 'grammarQuiz', 'quizProgress', 'annSeen'];
  function get(k, f) { try { var v = localStorage.getItem(k); return v === null ? f : JSON.parse(v); } catch (e) { return f; } }
  function put(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function icons() { if (window.lucide) try { lucide.createIcons(); } catch (e) {} }
  function el(h) { var d = document.createElement('div'); d.innerHTML = h.trim(); return d.firstChild; }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(s, r) { return (r || document).querySelector(s); }
  function toast(m) {
    document.querySelectorAll('.x-toast').forEach(function (t) { t.remove(); });
    var t = el('<div class="x-toast" role="status">' + esc(m) + '</div>'); document.body.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 300); }, 2400);
  }
  function shareUrl() { return CFG.url || (location.origin + location.pathname.replace(/[^/]*$/, '')); }
  function copy(t) {
    function ok() { toast('Link copied'); }
    function fb() { var i = document.createElement('textarea'); i.value = t; document.body.appendChild(i); i.select(); try { document.execCommand('copy'); ok(); } catch (e) {} i.remove(); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, fb); else fb();
  }
  function doShare() {
    var url = shareUrl(), msg = 'English Grammar for 2nd Year: notes, MCQ tests and quick questions. ';
    if (navigator.share) navigator.share({ title: 'English Grammar', text: msg, url: url }).catch(function () {}); else copy(url);
  }
  /* ---- quiz results: grammarQuiz = { "grammar-1.html": { "1": chosenIndex, ..., "_t": total } } ---- */
  function result(t) {
    var st = (get('grammarQuiz', {}) || {})[t.file] || {}, done = 0, ok = 0;
    Object.keys(t.answers).forEach(function (q) { if (typeof st[q] === 'number') { done++; if (st[q] === t.answers[q]) ok++; } });
    return { done: done, ok: ok, total: Object.keys(t.answers).length };
  }
  function readSet() { var r = get('readPages', []); return Array.isArray(r) ? r : []; }

  /* ---------- update notice ---------- */
  if ('serviceWorker' in navigator) {
    var had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!had || $('.x-update')) return;
      var b = el('<div class="x-update" role="status"><span>A new version is available</span><button type="button">Refresh</button></div>');
      b.querySelector('button').onclick = function () { location.reload(); }; document.body.appendChild(b);
    });
  }
  /* ---------- announcement banner (announcement.json: {"id":"..","text":".."}) ---------- */
  function announce() {
    if (!window.fetch || location.protocol === 'file:') return;
    fetch('announcement.json', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (a) {
      if (!a || !a.text || !a.id || get('annSeen', '') === a.id) return;
      var host = $('main'); if (!host) return;
      var b = el('<div class="gr-ann" role="status"><i data-lucide="megaphone"></i><span></span><button type="button" aria-label="Dismiss">×</button></div>');
      b.querySelector('span').textContent = a.text;
      b.querySelector('button').onclick = function () { put('annSeen', a.id); b.remove(); };
      host.insertBefore(b, host.firstChild); icons();
    }).catch(function () {});
  }
  /* ---------- install ---------- */
  var deferred = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; var b = $('#t-install'); if (b) b.hidden = false; });
  function installCard() {
    var standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone;
    if (standalone) return null;
    var c = el('<div class="gr-install"><div><b>Install this app</b><span id="ic-hint">Open it from your home screen, even offline.</span></div><button type="button" id="ic-btn">Install</button></div>');
    var btn = c.querySelector('#ic-btn'), hint = c.querySelector('#ic-hint');
    btn.onclick = function () {
      if (deferred) { deferred.prompt(); deferred.userChoice.finally(function () { deferred = null; }); }
      else { hint.textContent = 'Tap the ⋮ menu in Chrome, then choose "Add to Home screen" (iPhone: Share, then "Add to Home Screen").'; btn.hidden = true; }
    };
    window.addEventListener('appinstalled', function () { c.remove(); });
    return c;
  }
  /* ---------- exam date ---------- */
  function examCard(visible) {
    var c = el('<div class="x-card ' + (visible ? 'gr-exam' : 'x-exam') + '"><span class="x-ic"><i data-lucide="calendar-days"></i></span><div class="x-tx"><b>Exam date</b><small></small></div><label class="x-date"><span>Pick date</span><input type="date" aria-label="Exam date"></label></div>');
    var i = c.querySelector('input'), sm = c.querySelector('small'); i.value = get('examDate', '');
    function paint() {
      var v = i.value; if (!v) { sm.textContent = 'Pick the date to see the days left'; return; }
      var p = v.split('-'), n = new Date(), d = Math.round((Date.UTC(+p[0], +p[1] - 1, +p[2]) - Date.UTC(n.getFullYear(), n.getMonth(), n.getDate())) / 864e5);
      sm.textContent = d > 0 ? 'Exam in ' + d + ' days left' : d === 0 ? 'Exam is today — good luck!' : 'Date has passed — set a new one';
    }
    i.addEventListener('change', function () { if (i.value) put('examDate', i.value); else localStorage.removeItem('examDate'); paint(); toast('Exam date saved'); });
    paint(); return c;
  }
  /* ---------- home ---------- */
  function initHome() {
    var main = $('main'), hero = $('.hero'); if (!main || !hero) return;
    var ic = installCard(); if (ic) hero.insertAdjacentElement('afterend', ic);
    var q = $('.ios-quick-list'); if (!q) return;
    var wrap = el('<div class="x-home"></div>'); wrap.appendChild(examCard(false));
    /* topics to revisit: tests finished below 60 percent, then tests not started */
    var weak = [], fresh = [];
    T.forEach(function (t) { var r = result(t); if (r.done && r.total && r.ok / r.total < 0.6 && r.done === r.total) weak.push([t, r]); else if (!r.done) fresh.push(t); });
    var rows = '';
    weak.slice(0, 3).forEach(function (w) { rows += '<a class="x-row" href="' + w[0].file + '#mashq"><i data-lucide="rotate-ccw"></i><span><b>' + esc(w[0].title) + '</b><small>Score ' + w[1].ok + '/' + w[1].total + ' — retake the test</small></span><i data-lucide="chevron-right"></i></a>'; });
    if (!rows) fresh.slice(0, 3).forEach(function (t) { rows += '<a class="x-row" href="' + t.file + '#mashq"><i data-lucide="pencil-line"></i><span><b>' + esc(t.title) + '</b><small>' + t.mcq + ' MCQs waiting</small></span><i data-lucide="chevron-right"></i></a>'; });
    if (rows) wrap.appendChild(el('<div class="x-card x-today"><h3><i data-lucide="target"></i> ' + (weak.length ? 'Needs another try' : 'Try next') + '</h3>' + rows + '</div>'));
    q.parentNode.insertBefore(wrap, q); icons();
  }
  /* ---------- lesson ---------- */
  function initLesson() {
    var idx = -1; T.forEach(function (t, i) { if (t.file === PAGE) idx = i; }); if (idx < 0) return;
    var main = $('main'), head = $('.chapter-header');
    var words = (main.innerText || '').split(/\s+/).length, mins = Math.max(1, Math.round(words / 160));
    var t = T[idx];
    var tools = el('<div class="x-lesson-tools"><span class="x-chip"><i data-lucide="clock"></i>About ' + mins + ' min read</span>' +
      '<button type="button" class="x-chip" id="g-prac"><i data-lucide="pencil-line"></i>Practice</button>' +
      '<button type="button" class="x-chip" id="g-share"><i data-lucide="share-2"></i>Share</button>' +
      '<a class="x-chip" id="g-report" target="_blank" rel="noopener"><i data-lucide="flag"></i>Report a mistake</a></div>');
    if (head) head.parentNode.insertBefore(tools, head.nextSibling);
    $('#g-prac').onclick = function () { var d = document.querySelector('.lesson-dock [data-pane="mashq"]'); if (d) d.click(); else { var m = document.getElementById('mcq'); if (m) m.scrollIntoView(); } };
    $('#g-share').onclick = function () { var u = shareUrl() + t.file; if (navigator.share) navigator.share({ title: t.title, url: u }).catch(function () {}); else copy(u); };
    $('#g-report').href = 'https://wa.me/' + (CFG.wa || '') + '?text=' + encodeURIComponent('Mistake report - English Grammar, Topic ' + t.n + ': ' + t.title);
    var prev = T[idx - 1], next = T[idx + 1];
    var nav = el('<nav class="gr-pn" aria-label="Topics">' + (prev ? '<a href="' + prev.file + '"><i data-lucide="arrow-left"></i><span><small>Previous</small>' + esc(prev.title) + '</span></a>' : '<span></span>') +
      (next ? '<a href="' + next.file + '" class="next"><span><small>Next</small>' + esc(next.title) + '</span><i data-lucide="arrow-right"></i></a>' : '<a href="index.html" class="next"><span><small>All done</small>Back to topics</span><i data-lucide="home"></i></a>') + '</nav>');
    main.appendChild(nav);
    icons();
  }
  /* ---------- progress ---------- */
  function initProgress() {
    var host = $('#gr-progress'), read = readSet(), done = 0, tot = 0, ok = 0, answered = 0;
    var rows = T.map(function (t) {
      var r = result(t); tot += r.total; answered += r.done; ok += r.ok; var pct = r.total ? Math.round(r.ok * 100 / r.total) : 0;
      var cls = !r.done ? 'none' : r.done < r.total ? 'part' : pct >= 60 ? 'good' : 'weak';
      var state = !r.done ? 'Not started' : r.done < r.total ? r.done + '/' + r.total + ' answered' : r.ok + '/' + r.total + ' correct (' + pct + '%)';
      return '<a class="gr-prow ' + cls + '" href="' + t.file + '#mashq"><span class="n">' + (t.n < 10 ? '0' : '') + t.n + '</span><span class="tx"><b>' + esc(t.title) + '</b><small>' + (read.indexOf(t.file) > -1 ? 'Notes read · ' : '') + state + '</small></span><span class="bar"><i style="width:' + (r.total ? Math.round(r.done * 100 / r.total) : 0) + '%"></i></span></a>';
    }).join('');
    var nRead = T.filter(function (t) { return read.indexOf(t.file) > -1; }).length;
    host.innerHTML = '<div class="gr-stats"><div class="gr-stat"><i data-lucide="check-check"></i><b>' + nRead + '/' + T.length + '</b><span>Topics read</span></div>' +
      '<div class="gr-stat"><i data-lucide="pencil-line"></i><b>' + answered + '/' + tot + '</b><span>MCQs answered</span></div>' +
      '<div class="gr-stat"><i data-lucide="target"></i><b>' + (answered ? Math.round(ok * 100 / answered) + '%' : '—') + '</b><span>Accuracy</span></div></div>' +
      '<div class="gr-plist">' + rows + '</div>';
    icons();
  }
  /* ---------- more ---------- */
  function backup() {
    var out = { app: 'english-grammar', saved: new Date().toISOString(), data: {} };
    BACKUP_KEYS.forEach(function (k) { var v = localStorage.getItem(k); if (v !== null) out.data[k] = v; });
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(out)], { type: 'application/json' }));
    a.download = 'english-grammar-backup.json'; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast('Backup file saved');
  }
  function restore(f) {
    var r = new FileReader();
    r.onload = function () {
      try {
        var o = JSON.parse(r.result); if (!o || o.app !== 'english-grammar' || !o.data) throw 0;
        if (!confirm('Your current progress will be replaced by the backup. Continue?')) return;
        Object.keys(o.data).forEach(function (k) { if (BACKUP_KEYS.indexOf(k) > -1) localStorage.setItem(k, o.data[k]); });
        toast('Restored'); setTimeout(function () { location.reload(); }, 800);
      } catch (e) { toast('This file is not a valid backup'); }
    };
    r.readAsText(f);
  }
  function offline() {
    var m = $('#gr-offline'); if (!m) return;
    if (!('serviceWorker' in navigator) || !window.caches) { m.textContent = 'This browser cannot save the site for offline use.'; return; }
    m.textContent = 'Checking…';
    navigator.serviceWorker.ready.then(function () { return caches.keys(); }).then(function (ks) {
      var k = ks.filter(function (n) { return n.indexOf('engrammar-') === 0; })[0]; if (!k) throw 0;
      return caches.open(k).then(function (c) { return c.keys(); });
    }).then(function (r) { m.textContent = 'Ready offline — ' + r.length + ' files saved on this phone.'; }).catch(function () { m.textContent = 'Not ready yet. Stay online, reload the page once, then try again.'; });
  }
  function initMore() {
    $('#gr-exam').appendChild(examCard(true));
    $('#t-share').onclick = doShare; $('#t-backup').onclick = backup;
    $('#t-restore').onclick = function () { $('#t-file').click(); };
    $('#t-file').onchange = function (e) { if (e.target.files[0]) restore(e.target.files[0]); e.target.value = ''; };
    $('#t-offline').onclick = offline;
    $('#t-reset').onclick = function () {
      if (!confirm('Clear your read marks and MCQ answers? (Take a backup first if you want to keep them.)')) return;
      ['readPages', 'lessonProgress', 'grammarQuiz', 'quizProgress', 'visitDates', 'examDate'].forEach(function (k) { localStorage.removeItem(k); });
      toast('Cleared'); setTimeout(function () { location.reload(); }, 700);
    };
    var ib = $('#t-install'); if (deferred) ib.hidden = false;
    ib.onclick = function () { if (deferred) { deferred.prompt(); deferred = null; ib.hidden = true; } };
    if (/iphone|ipad/i.test(navigator.userAgent) && !navigator.standalone) $('#gr-offline').textContent = 'iPhone: open Safari\'s Share menu and choose "Add to Home Screen".';
  }
  function initShare() {
    var url = shareUrl(), msg = 'English Grammar for 2nd Year (KPK): notes, MCQ tests and quick questions. ';
    $('#s-wa').onclick = function () { window.open('https://wa.me/?text=' + encodeURIComponent(msg + url), '_blank', 'noopener'); };
    var sy = $('#s-sys'); if (!navigator.share) sy.hidden = true; else sy.onclick = doShare;
    $('#s-copy').onclick = function () { copy(url); };
    var img = $('#s-qr'); img.onerror = function () { img.closest('.gr-qr').hidden = true; };
  }
  document.addEventListener('DOMContentLoaded', function () {
    var f = { 'index.html': initHome, '': initHome, 'progress.html': initProgress, 'more.html': initMore, 'share.html': initShare }[PAGE];
    if (/^grammar-\d+\.html$/.test(PAGE)) f = initLesson;
    try { if (f) f(); } catch (e) { if (window.console) console.error(e); }
    if (PAGE === 'index.html' || PAGE === '') announce();
    icons();
  });
})();
