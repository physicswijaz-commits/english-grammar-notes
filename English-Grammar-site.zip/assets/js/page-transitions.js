/* ==========================================================================
   — Page transition (exit fade)
   Intercepts taps on internal links, fades the page out, then navigates —
   so moving between pages feels like one continuous app instead of a hard
   page-load cut. No-ops entirely under prefers-reduced-motion.
   ========================================================================== */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var FADE_MS = 160;

  document.addEventListener('click', function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    const a = e.target.closest('a[href]');
    if (!a) return;
    if (a.target === '_blank' || a.hasAttribute('download')) return;

    let url;
    try {
      url = new URL(a.getAttribute('href'), window.location.href);
    } catch (err) {
      return;
    }
    if (url.origin !== window.location.origin) return;
    /* Same-page anchors (e.g. #qa, #vocab section links) should jump
       instantly, not fade. */
    if (url.pathname === window.location.pathname && url.hash) return;

    e.preventDefault();
    document.body.classList.add('page-leaving');
    setTimeout(function () {
      window.location.href = a.href;
    }, FADE_MS);
  });

  /* Fires on every page display, including when the browser restores the
     page from bfcache on Back/Forward — where the DOM (and our
     'page-leaving' class from just before we navigated away) would
     otherwise come back exactly as we left it, i.e. invisible, until a
     manual refresh. Clearing the class here fixes that. */
  window.addEventListener('pageshow', function () {
    document.body.classList.remove('page-leaving');
  });
})();
