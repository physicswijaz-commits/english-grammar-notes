/* ==========================================================================
   Self-quiz mode — adds mastery tracking to existing Q&A cards.
   Works on any chapter page purely by scanning for .qa-card elements,
   so no per-chapter markup changes were needed.
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  const cards = document.querySelectorAll('.qa-card');
  if (!cards.length) return;

  const STORAGE_KEY = 'quizProgress'; // { "ch1.html#0": "know" | "learning" }
  const page = location.pathname.split('/').pop();

  function loadProgress() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
    catch (e) { return {}; }
  }
  function saveProgress(p) { localStorage.setItem(STORAGE_KEY, JSON.stringify(p)); }
  let progress = loadProgress();

  /* ---------- Inject mastery summary bar ---------- */
  const summary = document.createElement('div');
  summary.className = 'quiz-summary';
  summary.innerHTML =
    '<div class="quiz-summary-stat"><b id="quiz-known-count">0</b><span>Mastered</span></div>' +
    '<div class="quiz-summary-stat"><b id="quiz-learning-count">0</b><span>Still Learning</span></div>' +
    '<button id="quiz-filter-toggle" class="quiz-filter-btn">Show only unmastered</button>';
  const firstCard = cards[0];
  const container = firstCard.closest('section.topic') || firstCard.parentElement;
  container.insertBefore(summary, firstCard);

  const filterBtn = document.getElementById('quiz-filter-toggle');
  let filterOn = false;

  /* ---------- Give each card a stable key + inject mark buttons ---------- */
  cards.forEach((card, i) => {
    const key = page + '#' + i;
    const answer = card.querySelector('.qa-answer');
    const question = card.querySelector('.qa-question');
    if (!answer || !question) return;

    const badge = document.createElement('span');
    badge.className = 'quiz-badge';
    question.appendChild(badge);

    const row = document.createElement('div');
    row.className = 'quiz-mark-row';
    row.innerHTML =
      '<button class="quiz-mark-btn quiz-mark-learning" data-status="learning"><i data-lucide="rotate-ccw"></i> Still Learning</button>' +
      '<button class="quiz-mark-btn quiz-mark-know" data-status="know"><i data-lucide="check"></i> Got It</button>';
    answer.appendChild(row);

    function refreshCard() {
      const status = progress[key];
      badge.className = 'quiz-badge' + (status ? ' quiz-badge-' + status : '');
      badge.textContent = status === 'know' ? '✓' : status === 'learning' ? '!' : '';
      row.querySelectorAll('.quiz-mark-btn').forEach((b) => {
        b.classList.toggle('active', b.dataset.status === status);
      });
      card.classList.toggle('quiz-hidden', filterOn && status === 'know');
    }

    row.querySelectorAll('.quiz-mark-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const status = btn.dataset.status;
        progress[key] = progress[key] === status ? null : status; // tap again to unmark
        if (!progress[key]) delete progress[key];
        saveProgress(progress);
        refreshCard();
        refreshSummary();
      });
    });

    card._quizRefresh = refreshCard;
    refreshCard();
  });

  function refreshSummary() {
    let known = 0, learning = 0;
    cards.forEach((_, i) => {
      const s = progress[page + '#' + i];
      if (s === 'know') known++;
      if (s === 'learning') learning++;
    });
    document.getElementById('quiz-known-count').textContent = known;
    document.getElementById('quiz-learning-count').textContent = learning;
    if (window.lucide) { try { lucide.createIcons(); } catch (e) {} }
  }

  filterBtn.addEventListener('click', () => {
    filterOn = !filterOn;
    filterBtn.classList.toggle('active', filterOn);
    filterBtn.textContent = filterOn ? 'Show all questions' : 'Show only unmastered';
    cards.forEach((card) => card._quizRefresh());
  });

  refreshSummary();
  if (window.lucide) { try { lucide.createIcons(); } catch (e) {} }
});
