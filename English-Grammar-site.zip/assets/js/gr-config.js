window.GR_CFG = {"url": "https://physicswijaz-commits.github.io/english-grammar-notes/", "wa": "923409368103", "version": "v1"};
