/* ==========================================================================
      — Layout (v24)
   1. Header settings panel: theme / font / focus / practice live in ONE place
   2. Lesson pages: two cards —  (original text) and  (Q&A, vocabulary)
   Moves existing elements (listeners stay attached); adds no lesson content.
   ========================================================================== */
(function () {
  'use strict';
  function icons() { if (window.lucide) try { lucide.createIcons(); } catch (e) {} }
  function el(h) { var d = document.createElement('div'); d.innerHTML = h.trim(); return d.firstChild; }


  /* ---------- 0. MQ-style shell: header bar + drawer ---------- */
  function initShell() {
    var header = document.querySelector('header');
    if (!header || document.getElementById('x-drawer')) return;
    var page = location.pathname.split('/').pop() || 'index.html';
    var isHome = page === 'index.html';
    var gm = null; try { var cd = (typeof CHAPTERS_DATA !== 'undefined') ? CHAPTERS_DATA.filter(function (c) { return c.file === page; })[0] : null; if (cd) document.documentElement.setAttribute('data-genre', cd.type === 'Poem' ? 'nazam' : 'nasr'); else if (/^grammar/.test(page)) document.documentElement.setAttribute('data-genre', 'grammar'); } catch (e) {}
    var main = document.querySelector('main');
    var banner = main && main.querySelector(':scope > .chapter-header, :scope > .hero-block');
    var title, sub;
    if (banner) {
      title = (banner.querySelector('.eyebrow, .hero-type') || {}).textContent || document.title.split(' — ')[0];
      sub = '';   /* the chapter name is already the page heading */
    } else if (isHome) { title = 'English Grammar'; sub = '2nd Year'; }
    else { title = document.title.split(' — ')[0]; sub = 'English Grammar'; }
    title = title.replace(/\s*[·•]\s*Group.*$/, '');
    var back = header.querySelector('a.back-link');
    var backHref = back ? back.getAttribute('href') : null;
    var search = header.querySelector('.search-wrap');
    var theme = header.querySelector('.theme-switch'), font = document.getElementById('font-toggle'),
        focus = document.getElementById('focus-toggle'), practice = document.getElementById('practice-toggle');
    var sidebar = document.getElementById('sidebar');
    var sideNav = sidebar ? sidebar.cloneNode(true) : null;
    var oldMenu = document.getElementById('menu-toggle'); if (oldMenu) oldMenu.remove();

    header.className = 'bar';
    header.innerHTML = '<div class="bar-in"><button type="button" id="x-menu" class="icon-btn" aria-label="Open menu" aria-expanded="false" aria-controls="x-drawer"><i data-lucide="menu"></i></button>' +
      '<div class="bar-title"><b></b><small></small></div>' +
      '<div class="bar-pill"><button type="button" id="x-mode" class="pill-btn" aria-label="Light / dark"><i data-lucide="moon"></i></button>' +
      (backHref && !isHome ? '<a class="pill-btn" href="' + backHref + '" aria-label="Back"><i data-lucide="arrow-left"></i></a>' : '') + '</div></div>';
    header.querySelector('.bar-title b').textContent = title.trim();
    var sm = header.querySelector('.bar-title small'); if (sub.trim()) sm.textContent = sub.trim(); else sm.remove();
    if (search) { var sw = el('<div class="bar-search"></div>'); sw.appendChild(search); header.querySelector('.bar-in').insertBefore(sw, header.querySelector('.bar-pill')); }

    var nav = [['home', 'index.html', 'Topics'], ['search', 'index.html?focus=search', 'Search'], ['target', 'progress.html', 'My progress'], ['settings', 'more.html', 'More'], ['share-2', 'share.html', 'Share'], ['sparkles', 'whatsnew.html', 'What\'s new'], ['info', 'about.html', 'About'], ['shield-check', 'privacy.html', 'Privacy'], ['file-text', 'terms.html', 'Terms of Use']];
    var h = '<div class="dr-head"><b>English Grammar</b><button type="button" id="x-close" class="icon-btn" aria-label="Close"><i data-lucide="x"></i></button></div>';
    var pages = '<h3>Pages</h3>';
    nav.forEach(function (n) { pages += '<a class="d-link' + (n[1] === page ? ' cur' : '') + '" href="' + n[1] + '"><i data-lucide="' + n[0] + '"></i>' + n[2] + '</a>'; });
    var drawer = el('<aside id="x-drawer" aria-label="Menu">' + h + '<div class="dr-lesson"></div><h3>Settings</h3><div class="dr-set"></div><div class="dr-pages">' + pages + '</div></aside>');
    var lesson = drawer.querySelector('.dr-lesson');
    if (sideNav) {                                   /* : chapter contents */
      sideNav.querySelectorAll('.side-label').forEach(function (l) { var h3 = document.createElement('h3'); h3.textContent = l.textContent; l.replaceWith(h3); });
      sideNav.querySelectorAll('.drawer-head').forEach(function (d) { d.remove(); });
      sideNav.querySelectorAll('a').forEach(function (a) { a.className = 'd-link'; });
      lesson.appendChild(el('<h3>In this chapter</h3>'));
      Array.prototype.slice.call(sideNav.children).forEach(function (c) { if (c.tagName === 'NAV') { while (c.firstChild) lesson.appendChild(c.firstChild); } else if (c.tagName === 'H3' && c.textContent !== 'Content') lesson.appendChild(c); });
      lesson.querySelectorAll('h3').forEach(function (x) { if (x.textContent === 'Content') x.remove(); });
      sidebar.remove();
    } else if (banner) {
      lesson.innerHTML = '<h3>In this chapter</h3><a class="d-link" href="#top-lesson" data-pane="lesson"><i data-lucide="book-open"></i>Lesson</a><a class="d-link" href="#mashq" data-pane="mashq"><i data-lucide="pencil-line"></i>Practice</a>';
    }
    var set = drawer.querySelector('.dr-set');
    function row(label, node) { var r = el('<div class="d-row"><span></span><span class="d-ctl"></span></div>'); r.firstChild.textContent = label; r.lastChild.appendChild(node); set.appendChild(r); }
    if (theme) row('Theme', theme);
    if (font) row('Text size', font);
    if (focus) row('Focus mode', focus);
    if (practice) row('Explanation practice', practice);
    var bd = el('<div id="x-backdrop"></div>');
    document.body.appendChild(bd); document.body.appendChild(drawer);
    var layoutEl = document.querySelector('.layout'); if (layoutEl) layoutEl.classList.add('x-nosidebar');
    function open(o) { drawer.classList.toggle('open', o); bd.classList.toggle('open', o); document.body.classList.toggle('x-lock', o); header.querySelector('#x-menu').setAttribute('aria-expanded', String(o)); }
    header.querySelector('#x-menu').addEventListener('click', function () { open(true); });
    drawer.querySelector('#x-close').addEventListener('click', function () { open(false); });
    bd.addEventListener('click', function () { open(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') open(false); });
    drawer.addEventListener('click', function (e) { var a = e.target.closest('a.d-link'); if (!a) return; var pn = a.getAttribute('data-pane'); if (pn && window.__xShow) { e.preventDefault(); window.__xShow(pn, true); } open(false); });
    var modeBtn = header.querySelector('#x-mode');
    function icon() { var dark = document.documentElement.classList.contains('dark'); modeBtn.innerHTML = '<i data-lucide="' + (dark ? 'sun' : 'moon') + '"></i>'; icons(); }
    modeBtn.addEventListener('click', function () { var dark = document.documentElement.classList.contains('dark'); var d = document.querySelector('.theme-dot[data-t="' + (dark ? 'light' : 'dark') + '"]'); if (d) d.click(); setTimeout(icon, 60); });
    document.addEventListener('click', function (e) { if (e.target.closest('.theme-dot')) setTimeout(icon, 60); });
    icon();
  }

  /* ---------- 1. settings panel (replaced by the drawer) ---------- */
  function initSettings() {
    var header = document.querySelector('header');
    if (!header || document.getElementById('x-panel')) return;
    var theme = header.querySelector('.theme-switch'),
        font = document.getElementById('font-toggle'),
        focus = document.getElementById('focus-toggle'),
        practice = document.getElementById('practice-toggle');
    if (!theme && !font) return;
    var host = header.querySelector('.header-toggle-group') || header.querySelector('.header-actions');
    if (!host) {                               /* simple pages: chip + A + dots in .header-inner */
      host = el('<div class="header-toggle-group"></div>');
      (header.querySelector('.header-inner') || header).appendChild(host);
    }
    var btn = el('<button type="button" id="x-settings" aria-label="Appearance and settings" aria-expanded="false" aria-controls="x-panel"><i data-lucide="sliders-horizontal"></i></button>');
    var panel = el('<div class="x-panel" id="x-panel" role="dialog" aria-label="Appearance" hidden><div class="x-panel-title">Appearance</div></div>');
    function row(label, node, hint) {
      var r = el('<div class="x-prow"><span class="x-plabel">' + label + (hint ? '<small>' + hint + '</small>' : '') + '</span><span class="x-pctl"></span></div>');
      r.querySelector('.x-pctl').appendChild(node); panel.appendChild(r);
    }
    if (theme) row('Theme', theme, 'Light · Sepia · Dark');
    if (font) { font.classList.add('x-font'); row('Text size', font, 'Changes on each tap'); }
    if (focus) row('Focus mode', focus, 'Hide header and sidebar');
    if (practice) row('Explanation practice', practice, 'Hide explanations');
    host.innerHTML = ''; host.appendChild(btn);
    document.body.appendChild(panel);
    function set(open) { panel.hidden = !open; btn.setAttribute('aria-expanded', String(open)); btn.classList.toggle('on', open); }
    btn.addEventListener('click', function (e) { e.stopPropagation(); set(panel.hidden); });
    document.addEventListener('click', function (e) { if (!panel.hidden && !panel.contains(e.target)) set(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') set(false); });
    icons();
  }

  /* ---------- 2. lesson panes ---------- */
  function initPanes() {
    var main = document.querySelector('main');
    var banner = main && main.querySelector(':scope > .chapter-header, :scope > .hero-block');
    if (!banner || document.querySelector('.x-panes')) return;
    var isNasr = !!main.querySelector(':scope > .chapter-header');
    var kids = Array.prototype.slice.call(main.children);
    var mashq = [];
    kids.forEach(function (k, i) {
      var m = k.id === 'short-q' || k.id === 'long-q' || k.id === 'qa' || k.id === 'mcq' || k.id === 'vocab' || k.id === 'mushq' || k.classList.contains('exam-skeleton');
      if (m) mashq.push(k);
    });
    if (!mashq.length) {
      var rt0 = document.getElementById('read-toggle');
      if (rt0) { var f0 = el('<div class="x-finish"><div class="x-finish-main"></div><div class="x-finish-more"></div></div>'); f0.querySelector('.x-finish-main').appendChild(rt0); main.appendChild(f0); }
      var tEl = banner.querySelector('h1, .hero-title'), ch0 = document.querySelector('header .chip, header .type-chip');
      if (ch0 && tEl) { ch0.textContent = tEl.textContent.trim(); ch0.classList.add('x-title-chip'); }
      return;
    }
    /* the divider just before the first  block belongs with it */
    var first = mashq[0], prev = first.previousElementSibling;
    if (prev && /divider/.test(prev.className)) mashq.unshift(prev);
    kids.forEach(function (k) {
      if (k === banner) return;
      k.classList.add(mashq.indexOf(k) > -1 ? 'x-pane-mashq' : 'x-pane-lesson');
    });
    var bar = el('<div class="x-panes" role="tablist" aria-label="Lesson or practice">' +
      '<button type="button" role="tab" class="x-pane-tab" data-pane="lesson"><i data-lucide="book-open"></i><b>Lesson</b><small>' + (true ? 'Notes and key points' : 'Notes and explanation') + '</small></button>' +
      '<button type="button" role="tab" class="x-pane-tab" data-pane="mashq"><i data-lucide="pencil-line"></i><b>Practice</b><small>' + (true ? 'Q&A · vocabulary' : 'Q&A') + '</small></button></div>');
    /* header shows the chapter name; the end of the page carries the MQ-style finish area */
    var titleEl = banner.querySelector('h1, .hero-title');
    var chip = document.querySelector('header .chip, header .type-chip');
    if (chip && titleEl) { chip.textContent = titleEl.textContent.trim(); chip.classList.add('x-title-chip'); }
    var rt = document.getElementById('read-toggle');
    var finish = el('<div class="x-finish"><div class="x-finish-main"></div><div class="x-finish-more"></div></div>');
    if (rt) finish.querySelector('.x-finish-main').appendChild(rt);
    var tools = document.querySelector('.x-lesson-tools');
    if (tools) { var clock = tools.querySelector('.x-chip:not(a)'); if (clock) clock.remove(); finish.querySelector('.x-finish-more').appendChild(tools); }
    main.appendChild(finish);
    var dock = el('<nav class="tab-bar lesson-dock" aria-label="Lesson / Practice"><button type="button" class="tab-item" data-pane="lesson"><i data-lucide="book-open"></i><span>Lesson</span></button><button type="button" class="tab-item" data-pane="mashq"><i data-lucide="pencil-line"></i><span>Practice</span></button></nav>');
    document.body.appendChild(dock); document.body.classList.add('has-tab-bar');
    function updateFinish(p) { dock.querySelectorAll('.tab-item').forEach(function (b) { b.classList.toggle('active', b.dataset.pane === p); }); icons(); }
    dock.addEventListener('click', function (e) { var b = e.target.closest('.tab-item'); if (!b) return; show(b.dataset.pane, true); try { history.replaceState(null, '', b.dataset.pane === 'mashq' ? '#mashq' : location.pathname + location.search); } catch (x) {} });
    function paneOf(node) { var n = node; while (n && n !== main) { if (n.classList && (n.classList.contains('x-pane-mashq') || n.classList.contains('x-pane-lesson'))) return n.classList.contains('x-pane-mashq') ? 'mashq' : 'lesson'; n = n.parentElement; } return null; }
    function show(p, scroll) {
      document.body.setAttribute('data-pane', p);
      document.body.classList.toggle('x-in-mashq', p === 'mashq');
      bar.querySelectorAll('.x-pane-tab').forEach(function (b) { var on = b.dataset.pane === p; b.classList.toggle('active', on); b.setAttribute('aria-selected', String(on)); });
      if (scroll) window.scrollTo({ top: 0, behavior: 'auto' }); updateFinish(p);
    }
    bar.addEventListener('click', function (e) { var b = e.target.closest('.x-pane-tab'); if (b) { show(b.dataset.pane, true); try { history.replaceState(null, '', b.dataset.pane === 'mashq' ? '#mashq' : location.pathname + location.search); } catch (x) {} } });
    function target(h) { if (!h || h.length < 2) return null; if (h === '#mashq' && !document.getElementById('mashq')) return mashq.filter(function (n) { return n.tagName !== 'DIV'; })[0] || first; try { return document.querySelector(h); } catch (e) { return null; } }
    function goHash(h) { var t = target(h); var p = t && paneOf(t); if (p) { show(p, false); setTimeout(function () { t.scrollIntoView({ block: 'start' }); window.scrollBy(0, -70); }, 30); } }
    document.addEventListener('click', function (e) {
      var a = e.target.closest('a[href^="#"]'); if (!a) return;
      var t = target(a.getAttribute('href')); var p = t && paneOf(t); if (p && document.body.getAttribute('data-pane') !== p) { show(p, false); }
    }, true);
    window.addEventListener('hashchange', function () { goHash(location.hash); });
    var h = location.hash, t0 = target(h), p0 = t0 && paneOf(t0);
    window.__xShow = show;
    show(p0 || 'lesson', false);
    if (p0) goHash(h);
    icons();
  }

  /* ---------- 3. home: expandable chapter cards (like Mutalea Quran) ---------- */
  function initHomeCards() {
    var cards = document.querySelectorAll('.lc'); if (!cards.length) return;
    var read = [], lp = {};
    try { read = JSON.parse(localStorage.getItem('readPages') || '[]'); } catch (e) {}
    try { lp = JSON.parse(localStorage.getItem('chapterProgress') || '{}'); } catch (e) {}
    if (!Array.isArray(read)) read = Object.keys(read || {});
    cards.forEach(function (lc) {
      var a = lc.querySelector('a.card'), panel = lc.querySelector('.lc-panel'), go = lc.querySelector('.lc-go');
      var href = a.getAttribute('href'), n = lc.getAttribute('data-num'), word = lc.getAttribute('data-word') || 'chapter';
      var pct = read.indexOf(href) > -1 ? 100 : Math.min(99, (lp[href] && lp[href].pct) || 0);
      lc.style.setProperty('--p', pct + '%');
      var meta = a.querySelector('.card-poet');
      if (pct > 0 && pct < 100 && meta) { var em = document.createElement('span'); em.className = 'lc-pct'; em.textContent = pct + '% read'; meta.appendChild(em); }
      a.addEventListener('click', function (e) {
        e.preventDefault();
        var open = lc.classList.contains('open');
        document.querySelectorAll('.lc.open').forEach(function (o) { o.classList.remove('open'); o.querySelector('.lc-panel').hidden = true; });
        if (!open) { lc.classList.add('open'); panel.hidden = false; setTimeout(function () { lc.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 60); }
      });
      panel.querySelectorAll('.lc-opt').forEach(function (b) {
        b.addEventListener('click', function () {
          panel.querySelectorAll('.lc-opt').forEach(function (x) { x.classList.toggle('on', x === b); });
          var m = b.getAttribute('data-to').indexOf('#mashq') > -1;
          go.href = b.getAttribute('data-to'); go.textContent = (m ? 'Open practice · ' : 'Open ' + word + ' ') + n;
        });
      });
    });
    icons();
  }

  /* ---------- 4. footer on pages that have none (lessons, flashcards) ---------- */
  function initFooter() {
    if (document.querySelector('.site-foot')) return;
    var host = document.querySelector('main') || document.body;
    host.appendChild(el('<footer class="site-foot"><p class="made" dir="ltr">Made with <span class="heart" role="img" aria-label="love">♥</span> by <b>M. Ijaz</b></p><nav aria-label="Info"><a href="about.html">About</a><a href="privacy.html">Privacy</a><a href="terms.html">Terms of Use</a><a href="whatsnew.html">What\'s new</a></nav><small dir="ltr">© 2026 English Grammar</small></footer>'));
  }

  /* exam date: the card on the home page only shows the days left; editing lives in the drawer */
  function moveExamDate() {
    var tries = 0;
    (function go() {
      var lbl = document.querySelector('.x-exam .x-date'), set = document.querySelector('#x-drawer .dr-set');
      if (lbl && set) {
        var sp = lbl.querySelector('span'); if (sp) sp.remove();
        var r = el('<div class="d-row"><span>Exam date</span><span class="d-ctl"></span></div>');
        r.lastChild.appendChild(lbl); set.insertBefore(r, set.firstChild); return;
      }
      if (++tries < 40) setTimeout(go, 100);
    })();
  }

  function run() { initShell(); initPanes(); initHomeCards(); initFooter(); if (document.querySelector('.hero')) moveExamDate(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run); else run();
})();
